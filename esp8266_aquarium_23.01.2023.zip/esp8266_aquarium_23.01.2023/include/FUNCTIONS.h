#pragma once
#include <Arduino.h>
#include "GLOBAL.h"

void readJsonValues();
void updateTimeNTP();
void restart_esp();
void led_schedule();
byte fan_regulation(int temp, int setp, int hyst);
byte ten_regulation(int temp, int setp, int hyst);
byte rele_function(long s0, long s1, byte s_m);
void relay_schedule();
void update_chart_values();
void initOTA();

