#include "MQTT_WS.h"

int16_t sendOnChange(const char *key, const char *keyMQTT, int16_t state_new, int16_t state_old)
{
  char s_temp[10];
  (!strcmp(key, "temp")) ? strcpy(s_temp, String(float(state_new / 10.0)).c_str()) : strcpy(s_temp, String(state_new).c_str());
  if (state_new != state_old && !isUpdating)
  {
    if (state.ws)
    {
      strcpy(wsLive, "");
      StaticJsonDocument<512> root;
      root[key] = s_temp;
      serializeJson(root, wsLive);
      ws.textAll(wsLive);
    }
    events.send(String(state_new).c_str(), key, millis());
    if (mqttClient.connected() && strcmp(keyMQTT, ""))
      mqttClient.publish(keyMQTT, 0, true, s_temp);
  }
  return state_new;
}
const char *sendJson()
{
  strcpy(configLive, "");
  bitWrite(state.bf, 0, state.valNow);
  bitWrite(state.bf, 1, state.mqtt);
  bitWrite(state.bf, 2, state.rel2);
  bitWrite(state.bf, 3, state.rel1);
  bitWrite(state.bf, 4, state.ten);
  bitWrite(state.bf, 5, state.fan);  
  //bitWrite(state.bf, 4, ten_reg.getResult());
  //bitWrite(state.bf, 5, fan_reg.getResult());
  bitWrite(state.bf, 6, state.ws);
  StaticJsonDocument<512> root;
  root["now"] = rtc.now().timestamp();
  root["t"] = option.tempC;
  root["led"] = state.led;
  root["rssi"] = wifi.rssi;
  root["bf"] = state.bf;
  root["heap"] = state.heapMin;
  serializeJson(root, configLive);
  Serial.println(configLive);
  return configLive;
}
void connectToMqtt()
{
  if (!isUpdating && WiFi.isConnected()) {
    mqtt.server_ip.fromString(mqtt.server);
  mqttClient.setServer(mqtt.server_ip, mqtt.port);
  mqttClient.connect();
  //Serial.println(F("TRY TO CONNECT MQTT"));
  //Serial.printf("server: %s | port: %i\n", mqtt.server, mqtt.port);  
}
}
void onMqttConnect(bool sessionPresent)
{
  state.mqtt = 1;
  mqttReconnectTimer.detach();
  oldState.mqtt = sendOnChange("mqtt", "", state.mqtt, oldState.mqtt);
  mqttClient.publish(mqtt.t_all, 0, true, sendJson());
  Serial.print(F("[MQTT] MQTT CONNECTED!: "));
  Serial.println(state.mqtt);
}
void onMqttDisconnect(AsyncMqttClientDisconnectReason reason)
{
  mqttClient.disconnect();
  state.mqtt = 0;
  oldState.mqtt = sendOnChange("mqtt", "", state.mqtt, oldState.mqtt);
  if (strcmp(mqtt.server, "") && WiFi.isConnected())
  {
    Serial.print(F("[MQTT] MQTT DISCONNECTED!:"));
    Serial.println(state.mqtt);
    mqttReconnectTimer.once(2, connectToMqtt);
  }
}
void onWsEvent(AsyncWebSocket *server, AsyncWebSocketClient *client, AwsEventType type, void *arg, uint8_t *data, size_t len)
{
  byte id = client->id();
  if (type == WS_EVT_CONNECT)
  {
    state.ws++;
    if (!isUpdating)
      events.send(String(state.ws).c_str(), "ws", millis());
    Serial.print(F("[WS] WS CONNECTED. ID = "));
    Serial.println(id);
  }
  else if (type == WS_EVT_DISCONNECT)
  {
    Serial.print(F("[WS] WS DISCONNECTED. ID = "));
    Serial.println(id);
    ws.close(id);
    if (state.ws != 0 && !isUpdating)
    {
      state.ws--;
      events.send(String(state.ws).c_str(), "ws", millis());
    }
  }
}