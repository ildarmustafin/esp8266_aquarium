#include "main.h"

void IRAM_ATTR ledButton();
void IRAM_ATTR ipButton();
void IRAM_ATTR infoButton();

void readDateTime()
{
  state.valNow = rtc.now().isValid();
  if (!state.valNow)
  {
    if (state.valNow != oldState.valNow)
    {
      Serial.print(F("----.--.-- --:--:--]: Temp: "));
      Serial.print(option.tempC);
      Serial.print(F(" | LED_value: "));
      Serial.println(LED_value);
      oldState.valNow = state.valNow;
    }
    if (date_error < 10)
    {
      date_error++;
    }
    else
    {
      lcd_hour = 0;
      lcd_min = 0;
      lcd_sec = 0;
      state.led = 0;
      state.rel1 = 0;
      state.rel2 = 0;
      pwmController.setChannelOff(LEDPIN);
      pwmController.setChannelOff(RELAY1PIN);
      pwmController.setChannelOff(RELAY2PIN);
    }
  }
  else
  {
    sec_now = rtc.now().hour() * 3600 + rtc.now().minute() * 60 + rtc.now().second();
    ntp.week = ntp.dayOfWeek[rtc.now().dayOfTheWeek()];
    switch (ntp.week)
    {
    case 0:
      lcd.createChar(7, z_P);
      break;
    case 3:
      lcd.createChar(7, z_Ch);
      break;
    case 4:
      lcd.createChar(7, z_P);
      break;
    case 5:
      lcd.createChar(7, z_B);
      break;
    }
    lcd_hour = rtc.now().hour();
    lcd_min = rtc.now().minute();
    lcd_sec = rtc.now().second();
    led_schedule();
    relay_schedule();
    update_chart_values();
  }
}
void readTemp()
{
  sensors.setWaitForConversion(false);
  sensors.requestTemperatures();
  option.t = sensors.getTempCByIndex(0) * 10;
  // option.t = 127;
  if (option.t == -1270 || option.t == 850)
  {
    if (option.t != option.t_old)
    {
      Serial.print(F("["));
      (!state.valNow) ? Serial.print(F("----.--.-- --:--:--")) : Serial.print(rtc.now().timestamp());
      Serial.print(F("]: Temp: "));
      Serial.println(option.t);
      option.t_old = option.t;
    }
    if (temp_error < waitForTemp)
    {
      temp_error++;
    }
    else
    {
      option.tempC = option.t + option.temp_koef;
      state.ten = 0;
      state.fan = 0;
      pwmController.setChannelOff(FANPIN);
      pwmController.setChannelOff(TENPIN);
    }
  }
  else
  {
    temp_error = 0;
    option.tempC = option.t + option.temp_koef;
    switch (s_mode_f)
    {
      case 0:  //АВТО
        state.fan = fan_regulation(option.tempC, option.fan_set, option.fan_hyst);
        break;    
      case 1: //ВКЛ
        state.fan = 1;
        break;
      case 2: //ВЫКЛ
        state.fan = 0;
        break;
    }   
    uint8_t bfan = (state.inv_fan) ? !state.fan : state.fan;
    //Serial.println("[main 110] state.fan: " + String(state.fan));
    oldState.fan = sendOnChange("fan", mqtt.t_fan, state.fan, oldState.fan);
    pwmController.setChannelPWM(FANPIN, bfan * 4096);
    pwmController.setChannelPWM(FANLED, !bfan * 4096);
    //Serial.println("s_mode_f: " + String(s_mode_f) + " | state.fan: " + String(state.fan));
   switch (s_mode_t)
    {
      case 0:  //АВТО
        state.ten = ten_regulation(option.tempC, option.ten_set, option.ten_hyst);
        break;    
      case 1: //ВКЛ
        state.ten = 1;
        break;
      case 2: //ВЫКЛ
        state.ten = 0;
        break;
    }   
    uint8_t bten = (state.inv_ten) ? !state.ten : state.ten;
    oldState.fan = sendOnChange("ten", mqtt.t_ten, state.ten, oldState.ten);
    //Serial.println("[main 129] state.ten: " + String(state.ten));    
    pwmController.setChannelPWM(TENPIN, bten * 4096);
    pwmController.setChannelPWM(TENLED, !bten * 4096);    
  }
}
void measure_datetime()
{
  readDateTime();
  readTemp();
  state.heapCur = ESP.getFreeHeap();
  state.heapMin = (state.heapCur < state.heapMin) ? state.heapCur : state.heapMin;
  !strcmp(defLang, "RUS") ? strcpy(weekLang, daysOfTheWeekRUS[ntp.week]) : strcpy(weekLang, daysOfTheWeekENG[ntp.week]);
  if (state.heapMin != oldState.heapMin && !isUpdating)
  {
    events.send(String(state.heapMin).c_str(), "heap", millis());
    oldState.heapMin = state.heapMin;
  }
  line_show();
}
void noLight()
{
  lcd.noBacklight();
}
void showIP()
{
  flag.ipPressed = 0;
}
void showINFO()
{
  flag.infoPressed = 0;
}

void ledButton()
{
  b_led.tick();
}
void ipButton()
{
  b_ip.tick();
}
void infoButton()
{
  b_info.tick();
}

void send_data()
{
  if (isUpdating)
  {
    if (state.perc != oldState.perc)
    {
      events.send(String(state.perc).c_str(), "ota", millis());
      oldState.perc = state.perc;
    }
  }
  else
  {
    measure_datetime();
    pwmController.setChannelOn(DOP1LED);
    if (state.wifi == 1)
      wifi.rssi = WiFi.RSSI();
    flag.inc++;
    if (flag.inc >= 60)
    {
      oldState.rssi = sendOnChange("rssi", "rssi", wifi.rssi, oldState.rssi);
      // Serial.printf("[SSE] RSSI: %i\n", wifi.rssi);
      flag.inc = 0;
    }
    oldState.tempC = sendOnChange("temp", mqtt.t_temp, option.tempC, oldState.tempC);
    oldState.led = sendOnChange("led", mqtt.t_led, state.led, oldState.led);
    if (flag.serDebug)
    {
      if (str.indexOf("heap") > -1)
        Serial.printf("FRAGM: %i | CUR: %i | MIN: %i\n", ESP.getHeapFragmentation(), state.heapCur, state.heapMin);
      if (str.indexOf("led") > -1)
        Serial.printf("LED: %i | REL1: %i | REL2: %i\n", state.led, state.rel1, state.rel2);
      if (str.indexOf("temp") > -1)
        Serial.printf("TEMP: %2.1f | FAN: %i | TEN: %i\n", float(option.tempC) / 10, state.fan, state.ten);
      if (str.indexOf("wifi") > -1)
        Serial.printf("MODE: %i | STATE: %i | RSSI: %i\n", WiFi.getMode(), state.wifi, wifi.rssi);
    }
  }
}
void setup()
{
  Serial.begin(115200);
  Serial.println();
  pinMode(BUTPIN, INPUT_PULLUP);
  pinMode(IPPIN, INPUT_PULLUP);
  pinMode(INFOPIN, INPUT_PULLUP);

  attachInterrupt(digitalPinToInterrupt(BUTPIN), ledButton, CHANGE);
  attachInterrupt(digitalPinToInterrupt(IPPIN), ipButton, CHANGE);
  attachInterrupt(digitalPinToInterrupt(INFOPIN), infoButton, CHANGE);

  initLCD();
  initOTA();
  initFileSystem();
  Serial.printf("[SETUP] INITIAL PIN STATES:\n");
  Serial.printf("[SETUP] REL1: %i REL2: %i FAN: %i TEN: %i LED: %i\n", state.inv_rel1 * 4096, state.inv_rel2 * 4096, state.inv_fan * 4096, state.inv_ten * 4096, state.inv_led * 4096);
  pwmController.resetDevices();
  pwmController.init();
  pwmController.setPWMFrequency(1500);

  pwmController.setChannelOn(DOP1LED);
  pwmController.setChannelOn(DOP2LED);
  pwmController.setChannelOn(DOP3LED);
  pwmController.setChannelOn(DOP4LED);

  pwmController.setChannelOn(APLED);
  pwmController.setChannelOn(STALED);

  pwmController.setChannelPWM(FANPIN, state.inv_fan * 4096);
  pwmController.setChannelPWM(TENPIN, state.inv_ten * 4096);
  pwmController.setChannelPWM(RELAY1PIN, state.inv_rel1 * 4096);
  pwmController.setChannelPWM(RELAY2PIN, state.inv_rel2 * 4096);
  pwmController.setChannelPWM(LEDPIN, state.inv_led * 4096);

  pwmController.setChannelPWM(FANLED, !state.inv_fan * 4096);
  pwmController.setChannelPWM(TENLED, !state.inv_ten * 4096);
  pwmController.setChannelPWM(RELAY1LED, !state.inv_rel1 * 4096);
  pwmController.setChannelPWM(RELAY2LED, !state.inv_rel2 * 4096);
  pwmController.setChannelPWM(LEDLED, !state.inv_led * 4096);
  b_led.setDebounce(80);  // настройка антидребезга (по умолчанию 80 мс)
  b_led.setTimeout(300);  // настройка таймаута на удержание (по умолчанию 500 мс)
  b_ip.setDebounce(80);   // настройка антидребезга (по умолчанию 80 мс)
  b_ip.setTimeout(300);   // настройка таймаута на удержание (по умолчанию 500 мс)
  b_info.setDebounce(80); // настройка антидребезга (по умолчанию 80 мс)
  b_info.setTimeout(300); // настройка таймаута на удержание (по умолчанию 500 мс)
  Serial.printf("[SETUP] PWM PIN STATES INITIALIZED\n");
  snprintf(line2, 17, "FW:%s  FS:%s", ver.fw, ver.fs);
  printLCD(2, "  ESP8266_AQUA  ", line2);
  // WIFI_OFF = 0, WIFI_STA = 1, WIFI_AP = 2, WIFI_AP_STA = 3, WIFI_SHUTDOWN = 4, WIFI_RESUME = 8
  WiFi.persistent(false);
  WiFi.setSleepMode(WIFI_NONE_SLEEP);
  WiFi.hostname("ESP8266_AQUA");
  // WiFi.setOutputPower(12); //0 - 20.5 dBm
  if (!WiFi.getAutoConnect())
    WiFi.setAutoConnect(true);
  if (!WiFi.getAutoReconnect())
    WiFi.setAutoReconnect(true);
  WiFi_initSTA();
  Serial.printf("[SETUP] WIFI INITIALIZED\n");
  // WiFi_initAP_STA();
  STAconnected = WiFi.onStationModeConnected(&onStationConnected);
  STAgotIP = WiFi.onStationModeGotIP(&onStationGotIp);
  STAdisconnected = WiFi.onStationModeDisconnected(&onStationDisconnected);
  APconnected = WiFi.onSoftAPModeProbeRequestReceived(&onProbeRequestReceive);
  configTime(timeZone * 3600, 0, "pool.ntp.org", "time.nist.gov", "ntp3.stratum2.ru");
  sensors.begin();
  Serial.printf("[SETUP] SENSORS INITIALIZED\n");
  rtc.begin();
  Serial.printf("[SETUP] RTC INITIALIZED\n");
  timer_sendData.attach(1, send_data);
}
void loop()
{
  b_led.tick();
  b_ip.tick();
  b_info.tick();

  if (b_led.isSingle() && option.delLed)
  {
    // Serial.println("b_led Single");
    lcd.backlight();
    timer_once.once(option.delLed, noLight);
  }
  if (b_ip.isSingle() && !flag.ipPressed)
  {
    flag.infoPressed = 0;
    timerIP_once.once(3, showIP);
    flag.ipPressed = 1;
  }
  /*
  if (b_ip.isDouble())
  {
    s_flag2 = !s_flag2;
    s_mode_r2 = (s_flag2)?2:0;
    Serial.print("REL2: ");
    Serial.println(s_mode_r2);     
  }
  */
  if (b_info.isSingle() && !flag.infoPressed)
  {
    flag.ipPressed = 0;
    timerIP_once.once(3, showINFO);
    flag.infoPressed = 1;
  }
  /*
  if (b_info.isDouble())
  {
    s_flag1 = !s_flag1;
    s_mode_r1 = (s_flag1)?2:0;
    Serial.print("REL1: ");
    Serial.println(s_mode_r1);  
  }
  */
  ws.cleanupClients();
  ArduinoOTA.handle();
  if (Serial.available() > 0)
  {
    str = Serial.readString();
    if (str.indexOf("start") > -1)
      flag.serDebug = 1;
    if (str.indexOf("stop") > -1)
      flag.serDebug = 0;

    if (str.indexOf("stop") > -1)
    {
      /*
      strcpy(wifi.ssidAP, request->arg("input[3][3]").c_str());     // 32
      strcpy(wifi.passwordAP, request->arg("input[3][4]").c_str()); // 32
      strcpy(wifi.ssid, request->arg("input[3][5]").c_str());       // 32
      strcpy(wifi.password, request->arg("input[3][6]").c_str());   // 32
      strcpy(wifi.ip_str, request->arg("input[3][7]").c_str());     // 16
      strcpy(wifi.ip_gw_str, request->arg("input[3][8]").c_str());  // 16
      wifi.port = request->arg("input[3][9]").toInt();
      wifi.ip.fromString(wifi.ip_str);
      wifi.ip_gw.fromString(wifi.ip_gw_str);
      WiFi.scanNetworksAsync(printScanResult);
      jsonWrite(configSetup, "input", 3, 3, wifi.ssidAP);
      jsonWrite(configSetup, "input", 3, 4, wifi.passwordAP);
      jsonWrite(configSetup, "input", 3, 5, wifi.ssid);
      jsonWrite(configSetup, "input", 3, 6, wifi.password);
      jsonWrite(configSetup, "input", 3, 7, wifi.ip_str);
      jsonWrite(configSetup, "input", 3, 8, wifi.ip_gw_str);
      jsonWrite(configSetup, "input", 3, 9, wifi.port);
      saveConfig("/configSetup.json", configSetup);
      */
    }
  }
}
