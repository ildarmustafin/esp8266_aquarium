let but = []; 
let mes = []; 
let sch_title = [[],[]];
let defaultLang, restartMessage, restartTitle;
let parsed_day, parsed_month, parsed_year, parsed_hour, parsed_min;
let day_from, day_to, chartDays;
let days_in_prev_month = 0;
let once = false;
let flag = 1;
let chart, rssi;
let chart_base = [[31],[11]];
window.onload = function() {  
    openValues(); 
    init();
	liveValues();
};

function chartInputChange(n){
	let num = document.getElementById("input17").value;
    (n>0&&num<28)?num++:(n<0&&num>2)?num--:num;
    document.getElementById("input17").value = num;
    openChart(num);	
}

function openChart(n) {
	document.getElementById("input17").value=n;
	parsed_day>=n?(day_from=parsed_day-n+1,day_to=parsed_day):(days_in_prev_month=new Date(parsed_year,parsed_month-1,0).getDate(),day_from=days_in_prev_month-n+parsed_day+1,day_to=parsed_day);
 	updateChart();
}

function updateChart() {
	let xhttp = new XMLHttpRequest();
	xhttp.open("GET", "configChart.json", true);
	xhttp.onreadystatechange = function() {
		if (this.readyState == 4 && this.status == 200) {
			let jsonfile = JSON.parse(this.responseText);
/*=============================================================================================================================*/			
            let jsonVal = {"date":[],"values":[]};
            let k = day_from;
            let time_ost = (parsed_hour / 2);	
			if (day_from > day_to) {
				k = 1;
				for (let i = day_from; i <= days_in_prev_month; i++) {
					for (let j = 0; j <= 11; j++) {
						jsonVal.date.push(add_zero(i)+"."+add_zero(parsed_month-1)+"."+parsed_year+"_" + add_zero(j*2)+":00");
						jsonVal.values.push(jsonfile.days[i][j]);
					}
				} 	
			}
			
			for (let i = k; i <= (day_to-1); i++) {
				for (let j = 0; j <= 11; j++) {
					jsonVal.date.push(add_zero(i)+"."+add_zero(parsed_month)+"."+parsed_year+"_" + add_zero(j*2)+":00");
					jsonVal.values.push(jsonfile.days[i][j]);
				}
			} 

			for (let j = 0; j <= time_ost; j++) {
				jsonVal.date.push(add_zero(parsed_day)+"."+add_zero(parsed_month)+"."+parsed_year+"_" + add_zero(j*2)+":00");
				jsonVal.values.push(jsonfile.days[day_to][j]);
			}	
			let min = jsonVal.values[0];
			let max = min;			
			let aver = 0;
			for (i in jsonVal.values) {
				if (jsonVal.values[i] > max) max = jsonVal.values[i];
			    if (jsonVal.values[i] < min) min = jsonVal.values[i];
				aver += parseInt(jsonVal.values[i]);
			} 
			document.getElementById('chart_title0').value = 'min: '+min+' °C';
			document.getElementById('chart_title1').value = 'max: '+max+' °C';
			document.getElementById('chart_title2').value = 'aver: '+(aver / jsonVal.values.length).toFixed(2)+' °C';			
/*=============================================================================================================================*/	
            let line_min = document.getElementById('input5').value;
			let line_max = document.getElementById('input3').value;
			let line = line_max < max?[line_min,line_max]:[line_min];

			let data = {
				labels: jsonVal.date, 
				series: [jsonVal.values]
				};	
			let options = {
				height: '400px',
				showArea:true,
				axisX: {
					showLabel: false
				},	
				chartPadding: {
				    top: 15,
				    right: 5,
				    bottom: -25,
				    left: 10
				},				
				plugins: [
					Chartist.plugins.ctMultiThreshold({
						threshold: line
					}),				
				    Chartist.plugins.lineTooltip({
						appendTooltipContent: function (tooltip, data, pluginOptions) {
							var title = document.createElement('div');
							title.setAttribute('class', 'ct-tooltip-title');
							title.innerHTML = data.label;
							tooltip.appendChild(title);
							var seriesLabel;
							data.series.forEach(function (value) {
								seriesLabel = pluginOptions.createSeriesLabel({
									label  : value
								}, pluginOptions);
								tooltip.appendChild(seriesLabel);
							});
						},
						createSeriesLabel: function (options, pluginOptions) {
							var seriesLabel = document.createElement('div');
							seriesLabel.setAttribute('class', 'ct-tooltip-series-label');
							seriesLabel.innerHTML = '\
							<span class="ct-tooltip-legend ct-tooltip-legend-a"></span>\
							<span class="ct-tooltip-label">\
							' + options.label + '\
							' + " °C" + '\
							</span>';
							return seriesLabel;
						}		
					})
				]
			};
		    chart = new Chartist.Line('.ct-chart', data, options);
			chart.on('draw', function (data) {
				if (data.type === 'point') {
					let n = document.getElementById('input17').value;
					if (n >= 7) {
						data.element._node.setAttribute('style','stroke-width: 0px;');
					} else {
						data.element._node.setAttribute('style','stroke-width: 6px;');
					}	  
				}
			});
			var positionTooltip = function (tooltip, point) {
				tooltip.style.top  = (pointPosition.top - tooltipSize.height - 16) + 'px';
				if (point.index <= points.length / 2) {
					tooltip.style.left = (pointPosition.left - tooltipSize.width / 2 + 65) + 'px';	
					tooltip.classList.toggle('left');
				} else {
					tooltip.style.left = (pointPosition.left - tooltipSize.width / 2 - 70) + 'px';
					tooltip.classList.toggle('right');
				}
			};	
/*=============================================================================================================================*/	
		}
	};
	xhttp.send();
};

function changeZindex(n) {
      eventType	= n;
	  let elem = document.getElementsByClassName("tabs");
	  elem[0].style.zIndex = n * 10;	
}
function add_zero(n) {return n > 9 ? n: "0" + n; }

function changeLang(selectedLang) {
	event.preventDefault();
    openlang(selectedLang);
	let jsonData = 'defaultLang=' + selectedLang;
	let xhttp = new XMLHttpRequest();
	xhttp.open("GET", "lang?"+jsonData, true);
	xhttp.send();	
}

function openSchedule() {
	event.preventDefault();
	let selIndex = document.getElementById("select_schedule").options.selectedIndex;	
	let xhttp = new XMLHttpRequest();
	xhttp.open("GET", 'configSetup.json', true);
	xhttp.onreadystatechange = function() {
		if (this.readyState == 4 && this.status == 200) {
			let configSetup = JSON.parse(this.responseText);	
			for (let i = 0; i <= 5; ++i) {
				document.getElementById('sch_title'+(parseInt(i))).value = sch_title[selIndex][i];
			}
			for (let i = 0; i <= 6; i++) {
				for (let j = 0; j <= 3; j++) {
					document.getElementById('schedule'+(parseInt(i))+(parseInt(j))).value = configSetup.schedule[selIndex][i][j];
				}
			}			
		}
	};
	xhttp.send();
}

function openlang(lng) {
    let lang_path = lng+'.json';
	let selIndex = document.getElementById("select_schedule").options.selectedIndex;	
	let xhttp = new XMLHttpRequest();
	xhttp.open("GET", lang_path, true);
	xhttp.onreadystatechange = function() {
		if (this.readyState == 4 && this.status == 200) {
			let configSetup = JSON.parse(this.responseText);
			document.getElementById("text_s0").innerHTML = "&nbsp;&nbsp;&nbsp;" + configSetup.sch_title[0][0]; //Расписание светодиодов
			document.getElementById("text_s1").innerHTML = "&nbsp;&nbsp;&nbsp;" + configSetup.sch_title[0][1]; //Расписание реле
			for (let i = 0; i <= 24; i++)  { document.getElementById('text'+(parseInt(i))).innerHTML = configSetup.text_h[i]; } // поз.0-24
			for (let i = 10; i <= 15; i++) { document.getElementById('input'+(parseInt(i))).title = configSetup.text_h[26];   } //Требуется перезагрузка
			for (let i in configSetup.but) { but[i] = configSetup.but[i]; } //Сообщения ошибок RTC
			for (let i in configSetup.mes) { mes[i] = configSetup.mes[i]; } //Сообщения кнопок
			for (let i = 0; i <= 5; i++) { //Заголовки расписания
				sch_title[0][i] = configSetup.sch_title[1][i];
				sch_title[1][i] = configSetup.sch_title[2][i];
				document.getElementById('sch_title'+(parseInt(i))).value = sch_title[selIndex][i];
			}
			restartMessage = configSetup.text_h[25]; //Перезагрузить ESP8266-12E?
			document.getElementById("Button1").value = but[5]; //Сохранить расписание
			document.getElementById("Button2").value = but[6]; //Сохранить
			document.getElementById("Button3").value = but[6]; //Сохранить
			document.getElementById("Button4").value = but[3]; //Ручной ввод даты			
			document.getElementById("Button5").value = but[4]; //Автонастройка даты
			document.getElementById("Button6").innerHTML = but[7]; //Открыть
			document.getElementById("Button7").value = but[8]; //Загрузить
			document.getElementById("Button8").value = but[9]; //Перезагрузить
			document.getElementById("Button9").value = but[6]; //Сохранить
			document.getElementById("Button10").value = but[6]; //Сохранить
		}
	footerMessage('[GET]: Статус загрузки данных: ', this.status, 4000);		
	};
	xhttp.send();	
}

function openValues(){
    let selectList = document.getElementById("select_lang");
	let selIndex = document.getElementById("select_schedule").options.selectedIndex;	
	let xhttp = new XMLHttpRequest();
    xhttp.open("GET", 'configSetup.json', true);
	xhttp.onreadystatechange = function() {
		if (this.readyState == 4 && this.status == 200) {
			let configSetup = JSON.parse(this.responseText);
			for (let i in configSetup.lang){
				let option = document.createElement("option");
				option.value = configSetup.lang[i];
				option.text = configSetup.lang[i];
				selectList.appendChild(option);
			}
			document.getElementById("text_t1").innerText='ver: ' + configSetup.ver;
			selectList.value = configSetup.defaultLang;
			chartDays = configSetup.input[17]; //Количество дней в графике
			openlang(selectList.value);
			for (let i in configSetup.input) { document.getElementById('input'+(parseInt(i))).value = configSetup.input[i]; } //Все инпуты
			for (let i = 0; i <= 5; i++) { document.getElementById('sch_title'+(parseInt(i))).value = sch_title[selIndex][i] }
			for (let i = 0; i <= 6; i++) {
				for (let j = 0; j <= 3; j++) {
					document.getElementById('schedule'+(parseInt(i))+(parseInt(j))).value = configSetup.schedule[selIndex][i][j];
				}
			}
		}
	footerMessage('[GET]: Статус загрузки данных: ', this.status, 4000);	
	};
xhttp.send();
}

function ButtonClick(buttonNumb, method, url, setText, setBody) {
	let message = new Object();	
	message.loading = but[0];
	message.success = but[1];
	message.failure = but[2];
	let xhttp = new XMLHttpRequest();
	xhttp.onreadystatechange = function() {
		if (this.readyState == 4 && this.status == 200) {
			console.warn(message.success);
			footerMessage('[GET]: Статус отправки данных: ', this.status, 4000);			
			buttonNumb.value = message.success;
			buttonNumb.setAttribute("class", "btn btn-success");	
			setTimeout(() => { 
				buttonNumb.value = setText;
				buttonNumb.setAttribute("class", "btn btn-primary");			
			}, 1000);
		} else if (this.readyState < 4){
			console.warn(message.loading);
			buttonNumb.value = message.loading;
			buttonNumb.setAttribute("class", "btn btn-warning");	
		} else {
			console.warn(message.failure);
			footerMessage('[GET]: Статус отправки данных: ', this.status, 4000);				
			buttonNumb.value = message.failure;
			buttonNumb.setAttribute("class", "btn btn-danger");	
			setTimeout(() => { 
				buttonNumb.setAttribute("class", "btn btn-primary");
				buttonNumb.value = setText;
			}, 1000);
		}
	};
	xhttp.open(method, url, true);
	xhttp.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
    method == "GET"?xhttp.send():xhttp.send(setBody);
}

function init(){
	let button1 = document.getElementById("Button1");
	let button2 = document.getElementById("Button2");
	let button3 = document.getElementById("Button3");
	let button4 = document.getElementById("Button4");
	let button5 = document.getElementById("Button5");
	//let button6 = document.getElementById("Button6");   
	//let button7 = document.getElementById("Button7");
	let button8 = document.getElementById("Button8");
	let button9 = document.getElementById("Button9");
	let button10 = document.getElementById("Button10");
	
	button1.addEventListener("click", function(event){ 
		let sched = [[],[],[],[],[],[],[],[]];
		let selIndex = document.getElementById("select_schedule").options.selectedIndex;
		let jsonData = '';
		event.preventDefault(); 
		for (let i = 0; i <= 6; i++) {
			for (let j = 0; j <= 3; j++) {
				sched[i][j] = document.getElementById('schedule'+(parseInt(i))+(parseInt(j))).value;
				jsonData += 'schedule['+selIndex+']['+i+']['+j+']='+sched[i][j]+'&';
			}
		}
		ButtonClick(button1, "GET", 'save_schedule?selIndex='+selIndex+'&'+jsonData.substring(0, jsonData.length-1), but[5], ""); 
		
	});
	button2.addEventListener("click", function(event){ 
		let jsonData = '';
		event.preventDefault(); 
		for (let i = 0; i <= 6; i++) {
			jsonData += 'input['+i+']='+document.getElementById('input'+(parseInt(i))).value+'&';
		}
		ButtonClick(button2, "GET", 'save?'+jsonData.substring(0, jsonData.length-1), but[6], ""); 
	});	

	button3.addEventListener("click", function(event){ 
		let jsonData = '';
		event.preventDefault(); 
  		for (let i = 11; i <= 16; i++) {
			jsonData += 'input['+i+']='+document.getElementById('input'+(parseInt(i))).value+'&';
		} 
		ButtonClick(button3, "POST", '/ssid', but[6], jsonData.substring(0, jsonData.length-1)); 
	});	
	
	button4.addEventListener("click", function(event){ 
		event.preventDefault(); 
		let jsonData = 'input[7]=' + document.getElementById("input7").value + '&input[8]=' + document.getElementById("input8").value;
		ButtonClick(button4, "GET", 'save_date?'+jsonData, but[3], ""); 
	});
	
	button5.addEventListener("click", function(event){ 
		event.preventDefault(); 
		let jsonData = 'input[9]=' + document.getElementById("input9").value + '&input[10]=' + document.getElementById("input10").value;
		ButtonClick(button5, "GET", 'auto_sync?'+jsonData, but[4], ""); 
	});	

	button8.addEventListener("click", function(event){ 
		event.preventDefault(); 
		let jsonData = 'device=' + document.getElementById('device').value;
		ButtonClick(button8, "POST", '/restart', but[6], jsonData); 
	});	
	
	button9.addEventListener("click", function(event){ 
		event.preventDefault(); 
		let jsonData = 'input[17]=' + document.getElementById("input17").value;
		ButtonClick(button9, "GET", 'chartDays?'+jsonData, but[6], ""); 
	});	
	
	button10.addEventListener("click", function(event){ 
		event.preventDefault(); 
		let jsonData = 'input[17]=' + document.getElementById("input17").value;
		ButtonClick(button10, "GET", 'mqtt?'+jsonData, but[6], ""); 
	});		
}

function liveValues() {
    ws = new WebSocket("ws://" + window.location.hostname+":81/");
    //ws = new WebSocket("ws://echo.websocket.org");
    ws.onopen = function(event) {
/*
		setInterval(() => {
				Data = new Date();
				let now_ws = add_zero(Data.getDate())+'.'+add_zero(Data.getMonth()+1)+'.'+Data.getFullYear()+' '+add_zero(Data.getHours())+':'+add_zero(Data.getMinutes())+':'+add_zero(Data.getSeconds());
				let jsonLive = "{\"temp\":20.5,\"now\":\""+now_ws+"\",\"led\":0,\"fan\":1,\"ten\":1,\"rel1\":1,\"rel2\":1,\"rssi\":-56}";
				ws.send(jsonLive);
		}, 1000);
*/
		console.log("[OPEN] Websocket-соединение установлено...");
		footerMessage("[OPEN] Websocket-соединение установлено...", 0, 4000);
	};
    ws.onmessage = function(event) {
		//console.log("[message] Данные с сервера получены");
		//console.log(event.data);
		let json = JSON.parse(event.data);
		parsed_day = parseInt(json.now.substring(0, 2));
		parsed_month = parseInt(json.now.substring(3, 5));
		parsed_year = parseInt(json.now.substring(6, 10));
		parsed_hour = parseInt(json.now.substring(11, 13));
		parsed_min = parseInt(json.now.substring(14, 16));		
        if (parsed_day < 1 || parsed_day > 31 || parsed_month < 1 || parsed_month > 12 || parsed_hour < 0 || parsed_hour > 24 || parsed_min < 0 || parsed_min > 60){
            if (parsed_day == 165 || parsed_month == 165 || parsed_hour == 165 || parsed_min == 85) {
				document.getElementById("text_t3").innerHTML = mes[1];
				document.getElementById("text_t3").style="color:red;font-size:20px;line-height:20px;text-align:center;font-weight:bold;";
//				document.getElementById("text_t3").style="color:red;font-size:20px;width:65%;text-align:center;vertical-align:middle;display:table-cell;";
				console.log(json.now);
			} else {
				document.getElementById("text_t3").innerHTML = mes[2];
				document.getElementById("text_t3").style="color:red;font-size:20px;line-height:20px;text-align:center;font-weight:bold;";
//				document.getElementById("text_t3").style="color:red;font-size:20px;width:65%;text-align:center;vertical-align:middle;display:table-cell;";
				console.log(json.now);
			} 
		} else {
			if(!once) { openChart(chartDays); once = true; }
			let ostatok = parsed_hour % 2;
            (ostatok == 0 && flag == 0)?(num=document.getElementById("input17").value,flag=1,setTimeout(()=>{openChart(num);},3000)):
            (ostatok != 0)?flag=0:flag;
			document.getElementById("text_t3").innerHTML = json.now;
            document.getElementById("text_t3").style="color:white;font-size:20px;line-height:20px;text-align:center;font-weight:bold;";
//            document.getElementById("text_t3").style="color:white;font-size:20px;width:65%;text-align:center;vertical-align:middle;display:table-cell;";
		}
        class_wifi = json.rssi<=-110?'wifi1 mx-auto d-block':json.rssi<=-100?'wifi2 mx-auto d-block':json.rssi<=-85?'wifi3 mx-auto d-block':json.rssi<=-70?'wifi4 mx-auto d-block':json.rssi<=-50?'wifi5 mx-auto d-block':'wifi6 mx-auto d-block';
        class_led = json.led === 0 ? 'led_0 mx-auto d-block' : 'led_1 mx-auto d-block';
		class_fan = 'fan_' + json.fan +'  mx-auto d-block';
		class_ten = 'ten_' + json.ten +'  mx-auto d-block';
		class_relay1 = 'relay1_' + json.rel1 +'  mx-auto d-block';
		class_relay2 = 'relay2_' + json.rel2 +'  mx-auto d-block';
        document.getElementById("Picture2").setAttribute("class", class_wifi);
        document.getElementById("Picture3").setAttribute("class", class_led);
        document.getElementById("Picture4").setAttribute("class", class_fan);        
		document.getElementById("Picture5").setAttribute("class", class_ten);	
        document.getElementById("Picture6").setAttribute("class", class_relay1);        
		document.getElementById("Picture7").setAttribute("class", class_relay2);	
		document.getElementById("text_t5").innerHTML = json.led+"%";
		rssi = 'RSSI: '+json.rssi+' dBm';
        document.getElementById("Picture2").setAttribute('data-tooltip',rssi);


		(json.temp === 0.0) ? (
			document.getElementById("text_t2").innerHTML = mes[0],		
		    document.getElementById("Picture1").setAttribute("class", "tempna  mx-auto d-block")	
		):(
			document.getElementById("text_t2").innerHTML = json.temp + "°C",
		    document.getElementById("Picture1").setAttribute("class", "temp  mx-auto d-block")
		)
	};
    ws.onclose = function(event) {
		ws = null;
		console.log("[CLOSE] Websocket-соединение разорвано cо статусом: " + event.code);
		footerMessage('[CLOSE] Websocket-соединение разорвано cо статусом: ', event.code, 4000);
    };	
    ws.onerror = function(event) {
		console.log("[ERROR] Ошибка подключения...");
		footerMessage("[ERROR] Ошибка подключения...", event.code, 4000);
    };
};

function footerMessage(message, statusCode, delay) {
    let state = '';
	switch(statusCode) {
	    case   0:  state = ""; break;
	    case 200:  state = "OK"; break;
	    case 400:  state = "BAD REQUEST"; break;
	    case 403:  state = "FORBIDDEN"; break;
	    case 404:  state = "NOT FOUND"; break;
	    case 502:  state = "BAD GATEWAY"; break;		
	    case 503:  state = "SERVICE UNAVAILABLE"; break;	
	    case 504:  state = "GATEWAY TIMEOUT"; break;	
	    case 1000: state = "[1000] CLOSED NORMALLY"; break;	
	    case 1001: state = "[1001] SERVER GOING DOWN"; break;	
	    case 1002: state = "[1002] PROTOCOL ERROR"; break;
	    case 1003: state = "[1003] CAN\'T ACCEPT RECEIVED DATA"; break;
	    case 1004: state = "[1004]"; break;
	    case 1005: state = "[1005] NO STATUS CODE"; break;		
	    case 1006: state = "[1006] CLOSED ABNORMALLY"; break;	
	    case 1007: state = "[1007] DATA WITHIN MESSAGE"; break;	
	    case 1008: state = "[1008] MESSAGE THAT \"VIOLATES ITS POLICY\""; break;	
	    case 1009: state = "[1009] TOO BIG MESSAGE"; break;	
	    case 1010: state = "[1010]"; break;	
	    case 1011: state = "[1011]"; break;	
	    case 1015: state = "[1015] FAILURE TO PERFORM  A TLS HANDSHAKE"; break;			



		
	}	
	document.getElementById("reason").value = message + state;	
	setTimeout(() => { document.getElementById("reason").value = "";}, delay);	
 }	 
	 
let eventType = 0;	
document.addEventListener('touchstart', handleTouchStart, false);
document.addEventListener('touchmove', handleTouchMove, false);
document.addEventListener('touchend', handleTouchEnd, false);
let xDown = null;
let yDown = null;
let xDiff = null;
let yDiff = null;
let timeDown = null;
let startEl = null;

function handleTouchEnd(e) {
    if (startEl !== e.target) return;
    let swipeThreshold = 200; /* расстояние касания default 10px */
    let swipeTimeout = 1000;  /* время касания default 1000ms    */
    let timeDiff = Date.now() - timeDown;
    if (Math.abs(xDiff) > Math.abs(yDiff)) { // most significant
        if (Math.abs(xDiff) > swipeThreshold && timeDiff < swipeTimeout) {
            if (xDiff > 0) {
                eventType ++;				
				if (eventType > 4) eventType = 0;
            }
            else {
                eventType --;	
				if (eventType < 0) eventType = 4;
            }
        }
        changeZindex(eventType);
		document.getElementById('tab_'+ eventType).checked = true;		
		if (eventType==0) openChart(chartDays);		
    }
/*     else {
        if (Math.abs(yDiff) > swipeThreshold && timeDiff < swipeTimeout) {
            if (yDiff > 0) {
                //eventType = 'swiped-up';
                //document.getElementById("text_t1").innerText = 'up';
            }
            else {
                //eventType = 'swiped-down';
                //document.getElementById("text_t1").innerText = 'down';
            }
        }
    } */
    if (eventType !== '') {
        startEl.dispatchEvent(new CustomEvent(eventType, { bubbles: true, cancelable: true }));
    }
    xDown = null;
    yDown = null;
    timeDown = null;
};

function handleTouchStart(e) {
    if (e.target.getAttribute('data-swipe-ignore') === 'true') return;
    startEl = e.target;
    timeDown = Date.now();
    xDown = e.touches[0].clientX;
    yDown = e.touches[0].clientY;
    xDiff = 0;
    yDiff = 0;
};

function handleTouchMove(e) {
    if (!xDown || !yDown) return;
    let xUp = e.touches[0].clientX;
    let yUp = e.touches[0].clientY;
    xDiff = xDown - xUp;
    yDiff = yDown - yUp;
};

