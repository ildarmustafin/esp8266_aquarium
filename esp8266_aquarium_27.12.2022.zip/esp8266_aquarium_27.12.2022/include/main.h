#pragma once
#include <Arduino.h>
#include "GLOBAL.h"

void IRAM_ATTR ledButton();
void IRAM_ATTR ipButton();
void IRAM_ATTR infoButton();
void readDateTime();
void readTemp();
void measure_datetime();
void noLight();
void showIP();
void showINFO();
void ledButton();
void infoButton();
void ipButton();
void send_data();
void setup();
void loop();