#pragma once
#include <Arduino.h>
#include "GLOBAL.h"

void initFileSystem(void);

